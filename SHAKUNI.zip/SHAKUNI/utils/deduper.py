def remove_duplicates(words):
    return list(set(words))
